package com.example.myapplication.adapter

import MealModel
import FetchMeal
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.google.firebase.auth.FirebaseAuth

class MealAdapter(private val mealList: List<MealModel>) : RecyclerView.Adapter<MealAdapter.MealViewHolder>() {

    private val checkedItems = ArrayList<Boolean>()
    private lateinit var auth: FirebaseAuth
    init {
        for (i in mealList.indices) {
            checkedItems.add(false)
        }
    }

    class MealViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val mealCheckbox: CheckBox = itemView.findViewById(R.id.mealCheckbox)
        val mealType: TextView = itemView.findViewById(R.id.mealType)
        val mealText: TextView = itemView.findViewById(R.id.mealText)
        val mealTime: TextView = itemView.findViewById(R.id.mealTime)
        val mealStatus: TextView = itemView.findViewById(R.id.mealStatus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MealViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.meal_item, parent, false)
        return MealViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MealViewHolder, position: Int) {
        val currentItem = mealList[position]

        holder.mealType.text = currentItem.mealType
        holder.mealText.text = currentItem.text
        holder.mealTime.text = currentItem.time

        if (currentItem.hasEaten == "1") {
            holder.mealStatus.text = "Äten"
            // Gråa ut hela "måltiden"
            holder.itemView.alpha = 0.5f
            // Ta bort kryssrutan
            holder.mealCheckbox.visibility = View.GONE

        } else if (currentItem.hasEaten == "0") {
            holder.mealStatus.text = "Inte äten"
            // Återställ alfa och synlighet om de har ändrats
            holder.itemView.alpha = 1.0f
            holder.mealCheckbox.visibility = View.VISIBLE
        }

        holder.mealCheckbox.setOnCheckedChangeListener { _, isChecked ->
            checkedItems[position] = isChecked
            val helperInst = HelperFunctions()
            val userId = FirebaseAuth.getInstance().uid.toString()
            val currentDate = helperInst.currentDateToString()
            val fetchMeal = FetchMeal()

            if (isChecked) {
                fetchMeal.markMealAsEaten(userId, currentDate, currentItem.mealType)
                holder.mealStatus.text = "Äten"
                // Gråa ut hela "måltiden"
                holder.itemView.alpha = 0.5f
                // Ta bort kryssrutan
                holder.mealCheckbox.visibility = View.GONE
                holder.mealTime.visibility = View.GONE
                holder.mealText.visibility = View.GONE

            }
            else if(!isChecked){
                fetchMeal.markMealAsNotEaten(userId, currentDate, currentItem.mealType)
                holder.mealStatus.text = "Inte äten"
                // Återställ alfa och synlighet om de har ändrats
                holder.itemView.alpha = 1.0f
                holder.mealCheckbox.visibility = View.VISIBLE
            }
        }
    }


    override fun getItemCount() = mealList.size

    fun getCheckedItems(): List<Boolean> {
        return checkedItems.toList()
    }

}