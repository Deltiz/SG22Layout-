import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

data class MealModel(
    val mealType: String,
    val text: String,
    val time: String,
    val hasEaten: String
)

class FetchMeal {

    private val mealList = ArrayList<MealModel>()

    fun getMealsDatabase(userId: String, dateId: String, callback: (List<MealModel>) -> Unit) {
        val database = FirebaseDatabase.getInstance()
        val userRef = database.getReference("elders").child(userId).child(dateId)

        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    val mealData = dataSnapshot.getValue() as Map<*, *>
                    mealList.clear() // Clear the list before adding new data

                    for (key in mealData.keys) {
                        val mealItem = mealData[key] as Map<*, *>
                        val mealType = key as Any
                        val text = mealItem["text"].toString()
                        val time = mealItem["time"].toString()
                        val hasEaten = mealItem["eaten"].toString()


                        val mealModel = MealModel(mealType.toString(), text, time, hasEaten)
                        mealList.add(mealModel)
                    }

                    callback(mealList) // Pass the list to the callback
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Handle database errors if needed
            }
        })
    }


    fun markMealAsEaten(userId: String, dateId: String, mealType: String) {
        val database = FirebaseDatabase.getInstance()
        val userRef = database.getReference("elders").child(userId).child(dateId)
        val mealRef = userRef.child(mealType)
        mealRef.child("eaten").setValue(1)
    }

    fun markMealAsNotEaten(userId: String, dateId: String, mealType: String) {
        val database = FirebaseDatabase.getInstance()
        val userRef = database.getReference("elders").child(userId).child(dateId)
        val mealRef = userRef.child(mealType)
        mealRef.child("eaten").setValue(0)
    }
}
