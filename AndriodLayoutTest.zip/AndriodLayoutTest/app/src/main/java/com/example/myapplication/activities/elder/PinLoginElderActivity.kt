package com.example.myapplication.activities.elder

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import com.example.myapplication.databinding.ActivityPinLoginElderBinding

import android.os.Bundle
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth

class PinLoginElderActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPinLoginElderBinding
    //firebase auth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPinLoginElderBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val storedPin = pinAPI()
        binding.pinView.setOnCompletedListener = { pinCode ->
            if(pinCode == storedPin){
                startActivity(Intent(this@PinLoginElderActivity, DashboardUserActivity::class.java))
            }else{
                Toast.makeText(this,"Wrong Pin...", Toast.LENGTH_SHORT).show()
            }
            binding.pinView.clearPin()
        }
    }


    fun pinAPI():String {
        val userPin = "1234"
        return userPin
    }

}
