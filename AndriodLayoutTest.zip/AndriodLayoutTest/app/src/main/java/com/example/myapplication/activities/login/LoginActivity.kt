package com.example.myapplication.activities.login

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import com.example.myapplication.activities.caretaker.DashboardAdminActivity
import com.example.myapplication.activities.elder.DashboardUserActivity
import com.example.myapplication.databinding.ActivityLoginBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class LoginActivity : AppCompatActivity() {

    // view binding
    private lateinit var binding: ActivityLoginBinding

    //firebase auth
    private lateinit var firebaseAuth: FirebaseAuth

    //progress dialog
    private lateinit var progressDialog: ProgressDialog

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //init firebase auth
        firebaseAuth = FirebaseAuth.getInstance()

        // progress dialog, while login user
        progressDialog = ProgressDialog(this)
        progressDialog.setTitle("Vänta")
        progressDialog.setCanceledOnTouchOutside(false)

        binding.loginBackButton.setOnClickListener {
            onBackPressed()
        }

        binding.loginButton.setOnClickListener {
            validateData()
        }
    }

    private var email = ""
    private var password = ""
    private fun validateData() {
        // input data
        email = binding.usernameEditText.text.toString().trim()
        password = binding.passwordEditText.text.toString().trim()

        // validate
        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){
            Toast.makeText(this,"Invalid email...", Toast.LENGTH_SHORT).show()
        }
        else if (password.isEmpty()){
            Toast.makeText(this,"Enter password...", Toast.LENGTH_SHORT).show()
        }
        else{
            loginUser()
        }

    }

    private fun loginUser() {
        // login - firebase auth
        progressDialog.setMessage("Loggar in..")
        progressDialog.show()

        firebaseAuth.signInWithEmailAndPassword(email, password)
            .addOnSuccessListener {
                checkUserRole()
            }
            .addOnFailureListener{e->
                progressDialog.dismiss()
                Toast.makeText(this, "Login Failed: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun checkUserRole() {
        progressDialog.setMessage("Checking User...")

        val firebaseUser = firebaseAuth.currentUser!!

        val ref = FirebaseDatabase.getInstance().getReference("roles").child(firebaseUser.uid)

        ref.addListenerForSingleValueEvent(object : ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {
                progressDialog.dismiss()

                val userRole = snapshot.child("role").getValue(String::class.java)

                // Debugging: Print the userRole to check its value
                Log.d("UserRoleDebug", "User role: $userRole")

                when (userRole) {
                    "caretaker" -> {
                        startActivity(Intent(this@LoginActivity, DashboardAdminActivity::class.java))
                    }
                    "elder" -> {
                        startActivity(Intent(this@LoginActivity, DashboardUserActivity::class.java))
                    }
                    else -> {
                        Toast.makeText(this@LoginActivity, "User type does not exist: $userRole", Toast.LENGTH_SHORT).show()
                    }
                }

                finish()
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled if needed
            }
        })
    }

}