package com.example.myapplication.adapter

import android.content.Intent
import android.widget.Toast
import com.example.myapplication.activities.caretaker.DashboardAdminActivity
import com.example.myapplication.activities.elder.DashboardUserActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Date



class HelperFunctions {


    fun currentDateToString() : String{
        return SimpleDateFormat("dd-MM-yy").format(Date())
    }

    fun parseTime(timeValue: String): LocalTime {
        return LocalTime.parse(timeValue, DateTimeFormatter.ofPattern("HH:mm"))
    }

    fun getScheduledTimeInMS(timeValue: String): Long {
        val currentDate = LocalDate.now()
        val midnight = currentDate.atStartOfDay(ZoneId.of("Europe/Berlin"))
        val timeSek = parseTime(timeValue)
        val zonedDateTime = ZonedDateTime.of(midnight.toLocalDate(), timeSek, ZoneId.of("Europe/Berlin"))
        return zonedDateTime.toEpochSecond() * 1000
    }

    /*
    fun addMealPlan(mealType: String, time: String, text: String = "") {
        data class MealPlan (val eaten: Int, val text: String, val time: String)
        val dbRef = FirebaseDatabase.getInstance().getReference("elders").child("1234125")
        val dateReference = dbRef.child(currentDateToString()).child(mealType)
        val mealPlan = MealPlan(0, text, time)
        dateReference.setValue(mealPlan)
            .addOnSuccessListener {
                // Data successfully added
                // You can add any additional logic here
            }
            .addOnFailureListener {
                // Handle any errors that occurred
            }
    }
    */





}

