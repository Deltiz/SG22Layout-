package com.example.myapplication.activities.elder

import FetchMeal
import MealModel
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.myapplication.adapter.MealAdapter
import com.example.myapplication.databinding.ActivityDashboardUserBinding
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.myapplication.adapter.HelperFunctions
import com.google.firebase.auth.FirebaseAuth

class DashboardUserActivity : AppCompatActivity() {

    //update test
    private lateinit var binding: ActivityDashboardUserBinding
    private val mealList = ArrayList<MealModel>()
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        val userId = firebaseAuth.uid.toString()

        val helperInstance = HelperFunctions()
        val currentDate = helperInstance.currentDateToString()
        val fetchMeal = FetchMeal()
        fetchMeal.getMealsDatabase(userId, currentDate) { meals ->
            mealList.clear()
            mealList.addAll(meals)
            mealList.sortWith(compareBy { it.time })
            binding.recyclerView.adapter = MealAdapter(mealList)
            binding.recyclerView.layoutManager = LinearLayoutManager(this)
            binding.recyclerView.setHasFixedSize(true)
        }

        binding.refreshButton.setOnClickListener {
            this.recreate()
        }

    }

}