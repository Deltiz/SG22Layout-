package com.example.myapplication.activities

import android.app.AlarmManager
import android.app.AlertDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.example.myapplication.activities.caretaker.DashboardAdminActivity
import com.example.myapplication.activities.elder.DashboardUserActivity
import com.example.myapplication.activities.elder.PinLoginElderActivity
import com.example.myapplication.activities.login.LoginActivity
import com.example.myapplication.activities.login.RegisterActivity
import com.example.myapplication.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.ChildEventListener
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase
import com.example.myapplication.adapter.HelperFunctions

import com.example.myapplication.activities.Notification
import com.google.firebase.database.ValueEventListener

import java.util.Calendar
import java.util.Date

class MainActivity : AppCompatActivity() {
    companion object {
        var counter: Int = 0
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var auth: FirebaseAuth


    // check if user is elder to enable pin login, need to fix delay before
   public override fun onStart() {
        auth = Firebase.auth
        super.onStart()
        val firebaseUser = auth.currentUser!!
        val ref = FirebaseDatabase.getInstance().getReference("roles").child(firebaseUser.uid)

        ref.addListenerForSingleValueEvent(object : ValueEventListener {

            override fun onDataChange(snapshot: DataSnapshot) {

                val userRole = snapshot.child("role").getValue(String::class.java)

                if (userRole == "elder") {
                        startActivity(Intent(this@MainActivity, PinLoginElderActivity::class.java))
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle onCancelled if needed
            }
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.loginButton.setOnClickListener {
            startActivity(Intent(this@MainActivity, LoginActivity::class.java))
        }

        binding.regButton.setOnClickListener {
            startActivity(Intent(this@MainActivity, RegisterActivity::class.java))
        }

        createNotificationChannel()
        startDataBaseListener()
    }

    private fun startDataBaseListener() {
        val helperInstance = HelperFunctions()
        val auth = Firebase.auth
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val dbRef = FirebaseDatabase.getInstance().getReference("elders")
            val dbTime = dbRef.child(currentUser.uid).child(helperInstance.currentDateToString())
            dbTime.addChildEventListener(object : ChildEventListener {

                override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {

                    Log.d("Firebase", "Added")
                    val timeValue = snapshot.child("time").getValue(String::class.java)
                    if (timeValue != null) {
                        createMealPlanNotification(snapshot, timeValue)
                    }

                }

                override fun onChildRemoved(snapshot: DataSnapshot) {/* Handle removed child */
                }

                override fun onChildMoved(
                    snapshot: DataSnapshot,
                    previousChildName: String?
                ) {/* Handle moved child */
                }

                override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                    Log.d("Firebase", "onDataChange triggered")

                    val timeValue = snapshot.child("time").getValue(String::class.java)
                    if (timeValue != null) {
                        createMealPlanNotification(snapshot, timeValue)
                    } else {
                        Log.d("Firebase", "Did not enter IF")
                    }
                }

                override fun onCancelled(error: DatabaseError) {

                    Toast.makeText(applicationContext, "ERRORR ERRRORR", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }

    private fun createMealPlanNotification(snapshot: DataSnapshot, timeValue: String) {
        val helperInstance = HelperFunctions()
        val intent = Intent(applicationContext, Notification::class.java)
        val title = snapshot.getKey().toString()
        val message = snapshot.child("text").getValue(String::class.java)
        intent.putExtra(titleExtra, title)
        intent.putExtra(messageExtra, message)
        val pendingIntent = PendingIntent.getBroadcast(
            applicationContext, counter, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        counter++
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val time = helperInstance.getScheduledTimeInMS(timeValue)
        alarmManager.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            time,
            pendingIntent
        )
    }

    private fun createNotificationChannel() {
        val name = "Notification.kt Channel"
        val desc = "A description of the Channel"
        val importance = NotificationManager.IMPORTANCE_HIGH
        val channel = NotificationChannel(channelID, name, importance)
        channel.description = desc
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }
}




